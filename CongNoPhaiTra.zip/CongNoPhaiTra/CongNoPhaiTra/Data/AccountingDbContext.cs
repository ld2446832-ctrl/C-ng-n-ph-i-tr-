﻿using Microsoft.EntityFrameworkCore;
using CongNoPhaiTra.Models;

namespace CongNoPhaiTra.Data
{
    public class AccountingDbContext : DbContext
    {
        // Hàm khởi tạo nhận cấu hình chuỗi kết nối từ appsettings.json
        public AccountingDbContext(DbContextOptions<AccountingDbContext> options)
            : base(options)
        {
        }

        // Ánh xạ trực tiếp vào 3 bảng dữ liệu thực tế trong SSMS của bạn
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Payable> Payables { get; set; }
        public DbSet<Payment> Payments { get; set; }
    }
}