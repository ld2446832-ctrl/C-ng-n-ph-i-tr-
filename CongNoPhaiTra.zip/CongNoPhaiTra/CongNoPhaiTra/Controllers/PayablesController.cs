﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CongNoPhaiTra.Data;
using CongNoPhaiTra.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CongNoPhaiTra.Controllers
{
    public class PayablesController : Controller
    {
        private readonly AccountingDbContext _context;

        public PayablesController(AccountingDbContext context)
        {
            _context = context;
        }

        // GET: Payables
        public async Task<IActionResult> Index()
        {
            ViewBag.SupplierId = new SelectList(
                _context.Suppliers,
                "SupplierId",
                "SupplierName"
            );

            var list = await _context.Payables
                .Include(p => p.Supplier)
                .ToListAsync();

            return View(list);
        }

        // GET: Payables/Create
        public IActionResult Create()
        {
            ViewBag.SupplierId = new SelectList(
                _context.Suppliers,
                "SupplierId",
                "SupplierName"
            );

            return View();
        }

        // POST: Payables/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            [Bind("SupplierId,InvoiceNumber,TotalAmount,InvoiceDate,DueDate,Status")]
            Payable payable)
        {
            ModelState.Remove("Supplier");

            if (payable.InvoiceDate == DateTime.MinValue)
                payable.InvoiceDate = DateTime.Now;

            if (string.IsNullOrEmpty(payable.Status))
                payable.Status = "Chưa thanh toán";

            if (ModelState.IsValid)
            {
                _context.Add(payable);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.SupplierId = new SelectList(
                _context.Suppliers,
                "SupplierId",
                "SupplierName",
                payable.SupplierId
            );

            return View(payable);
        }

        // GET: Payables/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var payable = await _context.Payables.FindAsync(id);

            if (payable == null)
                return NotFound();

            ViewBag.SupplierId = new SelectList(
                _context.Suppliers,
                "SupplierId",
                "SupplierName",
                payable.SupplierId
            );

            return View(payable);
        }

        // POST: Payables/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            [Bind("PayableId,SupplierId,InvoiceNumber,TotalAmount,InvoiceDate,DueDate,Status")]
            Payable payable)
        {
            if (id != payable.PayableId)
                return NotFound();

            ModelState.Remove("Supplier");

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(payable);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Payables.Any(e => e.PayableId == id))
                        return NotFound();

                    throw;
                }

                return RedirectToAction(nameof(Index));
            }

            ViewBag.SupplierId = new SelectList(
                _context.Suppliers,
                "SupplierId",
                "SupplierName",
                payable.SupplierId
            );

            return View(payable);
        }

        // GET: Payables/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var payable = await _context.Payables.FindAsync(id);

            if (payable != null)
            {
                _context.Payables.Remove(payable);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    }
}