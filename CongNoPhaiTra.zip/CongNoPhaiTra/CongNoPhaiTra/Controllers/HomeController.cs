﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CongNoPhaiTra.Data;

namespace CongNoPhaiTra.Controllers
{
    public class HomeController : Controller
    {
        private readonly AccountingDbContext _context;

        public HomeController(AccountingDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var data = await _context.Payables
                .Include(p => p.Supplier)
                .Include(p => p.Payments)
                .ToListAsync();

            decimal totalPayables = data.Sum(p => p.TotalAmount ?? 0m);

            decimal totalPaid = data.Sum(p =>
                p.Payments.Sum(x => x.Amount));

            decimal remaining = totalPayables - totalPaid;

            ViewBag.TotalPayables = totalPayables;
            ViewBag.TotalPaid = totalPaid;
            ViewBag.Remaining = remaining;

            return View(data);
        }
    }
}