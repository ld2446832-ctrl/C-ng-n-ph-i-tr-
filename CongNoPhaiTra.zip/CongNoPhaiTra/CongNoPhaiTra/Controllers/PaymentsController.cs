﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CongNoPhaiTra.Data;
using CongNoPhaiTra.Models;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CongNoPhaiTra.Controllers
{
    public class PaymentsController : Controller
    {
        private readonly AccountingDbContext _context;

        public PaymentsController(AccountingDbContext context)
        {
            _context = context;
        }

        // GET: Payments
        public async Task<IActionResult> Index()
        {
            ViewBag.PayableId = new SelectList(_context.Payables, "PayableId", "InvoiceNumber");
            var list = await _context.Payments.Include(p => p.Payable).ThenInclude(p => p.Supplier).ToListAsync();
            return View(list);
        }

        // POST: Payments/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
    [Bind("PaymentId,PayableId,PaymentDate,Amount,Note")] Payment payment)
        {
            if (payment.PaymentDate == DateTime.MinValue)
                payment.PaymentDate = DateTime.Now;

            _context.Payments.Add(payment);

            var payable = await _context.Payables
                .FirstOrDefaultAsync(p => p.PayableId == payment.PayableId);

            if (payable != null)
            {
                payable.PaidAmount = (payable.PaidAmount ?? 0m) + payment.Amount;

                if ((payable.PaidAmount ?? 0m) >= (payable.TotalAmount ?? 0m))
                {
                    payable.Status = "Đã thanh toán";
                }
            }

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: Payments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var payment = await _context.Payments.FindAsync(id);
            if (payment == null) return NotFound();

            ViewBag.PayableId = new SelectList(_context.Payables, "PayableId", "InvoiceNumber", payment.PayableId);
            return View(payment);
        }

        // POST: Payments/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PaymentId,PayableId,PaymentDate,Amount,Note")] Payment payment)
        {
            if (id != payment.PaymentId) return NotFound();

            _context.Update(payment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Payments/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var payment = await _context.Payments.FindAsync(id);

            if (payment != null)
            {
                var payable = await _context.Payables
                    .FindAsync(payment.PayableId);

                if (payable != null)
                {
                    payable.PaidAmount =
                        (payable.PaidAmount ?? 0m) - payment.Amount;

                    if (payable.PaidAmount < 0)
                        payable.PaidAmount = 0;

                    payable.Status =
                        payable.PaidAmount >= payable.TotalAmount
                        ? "Đã thanh toán"
                        : "Chưa thanh toán";
                }

                _context.Payments.Remove(payment);

                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
