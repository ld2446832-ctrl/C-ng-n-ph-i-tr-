﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CongNoPhaiTra.Models
{
    public class Payable
    {
        [Key]
        public int PayableId { get; set; }

        public string? InvoiceNumber { get; set; }

        [Required]
        public DateTime DueDate { get; set; }

        public DateTime InvoiceDate { get; set; }

        public string? Status { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? TotalAmount { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? PaidAmount { get; set; }

        [NotMapped]
        public decimal RemainingAmount =>
            (TotalAmount ?? 0m) - (PaidAmount ?? 0m);

        public int SupplierId { get; set; }

        public virtual Supplier? Supplier { get; set; }

        public virtual ICollection<Payment> Payments { get; set; }
            = new List<Payment>();
    }
}