﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CongNoPhaiTra.Models
{
    [Table("Payments")]
    public class Payment
    {
        [Key]
        public int PaymentId { get; set; }

        [Required]
        public decimal Amount { get; set; }

        // Thuộc tính này đang bị thiếu khiến code báo lỗi CS1061
        [Required]
        public DateTime PaymentDate { get; set; } = DateTime.Now;

        public string? Note { get; set; }

        [Required]
        public int PayableId { get; set; }

        [ForeignKey("PayableId")]
        public Payable? Payable { get; set; }
    }
}