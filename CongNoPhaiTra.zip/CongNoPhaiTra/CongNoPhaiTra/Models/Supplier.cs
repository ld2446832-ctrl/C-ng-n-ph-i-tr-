﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CongNoPhaiTra.Models
{
    [Table("Suppliers")]
    public class Supplier
    {
        [Key]
        public int SupplierId { get; set; }

        [Required(ErrorMessage = "Tên nhà cung cấp không được để trống")]
        public string SupplierName { get; set; } = string.Empty; // Khởi tạo giá trị mặc định

        public string? Address { get; set; } // Thêm dấu ? để cho phép giá trị null

        public string? Phone { get; set; }   // Thêm dấu ? để cho phép giá trị null

        public string? Email { get; set; }   // Thêm dấu ? để cho phép giá trị null

        // Mối quan hệ liên kết (Đảm bảo khởi tạo để tránh lỗi NullReference)
        public ICollection<Payable> Payables { get; set; } = new List<Payable>();
    }
}